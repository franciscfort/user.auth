<?php
if(isset($_POST['submit'])){
    $username = //finish this line
    $password = //finish this

loginUser($email, $password);

}

function loginUser($email, $password){
    /*
        Finish this function to check if username and password 
    from file match that which is passed from the form
    */
}

echo "HANDLE THIS PAGE";

